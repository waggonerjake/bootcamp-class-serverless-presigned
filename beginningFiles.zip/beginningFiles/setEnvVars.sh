export GITHUB_USERNAME="<<username>>"
export GITHUB_REPO="bootcamp-2022-sls-api-<<lastname>>"
export BUCKET_NAME="<<username>>-bootcamp-2022-bucket" #username must be all lowercase