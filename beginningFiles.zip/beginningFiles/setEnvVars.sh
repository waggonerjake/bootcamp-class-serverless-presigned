export GITHUB_USERNAME="<<username>>"
export GITHUB_REPO="bootcamp-2022-sls-api-<<lastname>>.git"
export BUCKET_NAME="<<username>>-bootcamp-2022-bucket" #username must be all lowercase